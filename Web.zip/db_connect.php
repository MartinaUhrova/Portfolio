<?php
// $host = "localhost";
$host = "sql6.webzdarma.cz";
$userName = "martinauhrov2833";
$password = "*Emilka2021*";
$dbName = "martinauhrov2833";

$connection = new mysqli($host, $userName, $password, $dbName);
